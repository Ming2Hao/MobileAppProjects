package com.example.m3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.m3.databinding.ActivityGameBinding

class Game : AppCompatActivity() {
    private lateinit var labelScore: TextView
    private lateinit var binding: ActivityGameBinding
    // late inint a 5x5 array
    private lateinit var array: Array<Array<String>>
    private lateinit var buttons: Array<Array<Button>>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        binding = ActivityGameBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        var intent = getIntent()
        binding.labelNama.text = intent.getStringExtra("nama")
        var counterClick = 1
        var tempX = -1
        var tempY = -1
        var score = 0
        var selese=false
        var counterdblclick=1
        var listcolors =
                arrayOf(
                        arrayOf("1", "2", "3", "4", "5"),
                        arrayOf("1", "2", "3", "4", "5"),
                        arrayOf("1", "2", "3", "4", "5"),
                        arrayOf("1", "2", "3", "4", "5"),
                        arrayOf("1", "2", "3", "4", "5")
                )
        buttons =
                arrayOf(
                        arrayOf(binding.b00, binding.b01, binding.b02, binding.b03, binding.b04),
                        arrayOf(binding.b10, binding.b11, binding.b12, binding.b13, binding.b14),
                        arrayOf(binding.b20, binding.b21, binding.b22, binding.b23, binding.b24),
                        arrayOf(binding.b30, binding.b31, binding.b32, binding.b33, binding.b34),
                        arrayOf(binding.b40, binding.b41, binding.b42, binding.b43, binding.b44)
                )

        var tempwarna =
                arrayOf(
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1
                )
        for (i in 0..3) {
            var ctr = 0
            while (ctr < 6) {
                var random = (0..24).random()
                if (tempwarna[random] == -1) {
                    tempwarna[random] = i
                    ctr++
                }
            }
        }
        for (i in 0..24) {
            if (tempwarna[i] == -1) {
                var random = (0..3).random()
                tempwarna[i] = random
            }
        }
        for (i in 0..4) {
            for (j in 0..4) {
                if (tempwarna[i * 5 + j] == 0) {
                    buttons[i][j].setBackgroundColor(
                            ContextCompat.getColor(applicationContext, R.color.blue)
                    )
                    listcolors[i][j] = "blue"
                } else if (tempwarna[i * 5 + j] == 1) {
                    buttons[i][j].setBackgroundColor(
                            ContextCompat.getColor(applicationContext, R.color.pink)
                    )
                    listcolors[i][j] = "pink"
                } else if (tempwarna[i * 5 + j] == 2) {
                    buttons[i][j].setBackgroundColor(
                            ContextCompat.getColor(applicationContext, R.color.green)
                    )
                    listcolors[i][j] = "green"
                } else if (tempwarna[i * 5 + j] == 3) {
                    buttons[i][j].setBackgroundColor(
                            ContextCompat.getColor(applicationContext, R.color.orange)
                    )
                    listcolors[i][j] = "orange"
                }
            }
        }
        for (i in 0..4) {
            for (j in 0..4) {
                buttons[i][j].setOnClickListener {
                    //                    Toast.makeText(this, "Button $i $j clicked",
                    // Toast.LENGTH_SHORT).show()
                    if (counterClick == 1) {
                        tempX = i
                        tempY = j
                        counterClick++
                    } else if (counterClick == 2) {
                        counterClick = 1
                        var valid = false
                        var temparah = ""
                        if (i == tempX && j == tempY + 1) {
                            valid = true
                            temparah = "y"
                        } else if (i == tempX && j == tempY - 1) {
                            valid = true
                            temparah = "y"
                        } else if (i == tempX + 1 && j == tempY) {
                            valid = true
                            temparah = "x"
                        } else if (i == tempX - 1 && j == tempY) {
                            valid = true
                            temparah = "x"
                        }
                        if (valid == false) {
                            Toast.makeText(this, "Invalid Move", Toast.LENGTH_SHORT).show()
                        } else {
                            counterClick = 1
                            if (listcolors[tempX][tempY] == "purple" || listcolors[i][j] == "purple"
                            ) {
                                if (temparah == "x") {
                                    for (z in 0..4) {
                                        if (listcolors[z][j] != "white") {
                                            buttons[z][j].setBackgroundColor(
                                                    ContextCompat.getColor(
                                                            applicationContext,
                                                            R.color.white
                                                    )
                                            )
                                            listcolors[z][j] = "white"
                                            score++
                                        }
                                    }
                                } else if (temparah == "y") {
                                    for (z in 0..4) {
                                        if (listcolors[i][z] != "white") {
                                            buttons[i][z].setBackgroundColor(
                                                    ContextCompat.getColor(
                                                            applicationContext,
                                                            R.color.white
                                                    )
                                            )
                                            listcolors[i][z] = "white"
                                            score++
                                        }
                                    }
                                }
                                binding.labelScore.text = score.toString()
                            } else {
                                var temptukerwarna = listcolors[tempX][tempY]
                                var temptukerwarna2 = listcolors[i][j]
                                if (temptukerwarna == "blue") {
                                    buttons[i][j].setBackgroundColor(
                                            ContextCompat.getColor(applicationContext, R.color.blue)
                                    )
                                    listcolors[i][j] = "blue"
                                } else if (temptukerwarna == "pink") {
                                    buttons[i][j].setBackgroundColor(
                                            ContextCompat.getColor(applicationContext, R.color.pink)
                                    )
                                    listcolors[i][j] = "pink"
                                } else if (temptukerwarna == "green") {
                                    buttons[i][j].setBackgroundColor(
                                            ContextCompat.getColor(
                                                    applicationContext,
                                                    R.color.green
                                            )
                                    )
                                    listcolors[i][j] = "green"
                                } else if (temptukerwarna == "orange") {
                                    buttons[i][j].setBackgroundColor(
                                            ContextCompat.getColor(
                                                    applicationContext,
                                                    R.color.orange
                                            )
                                    )
                                    listcolors[i][j] = "orange"
                                } else if (temptukerwarna == "white") {
                                    buttons[i][j].setBackgroundColor(
                                            ContextCompat.getColor(
                                                    applicationContext,
                                                    R.color.white
                                            )
                                    )
                                    listcolors[i][j] = "white"
                                }
                                if (temptukerwarna2 == "blue") {
                                    buttons[tempX][tempY].setBackgroundColor(
                                            ContextCompat.getColor(applicationContext, R.color.blue)
                                    )
                                    listcolors[tempX][tempY] = "blue"
                                } else if (temptukerwarna2 == "pink") {
                                    buttons[tempX][tempY].setBackgroundColor(
                                            ContextCompat.getColor(applicationContext, R.color.pink)
                                    )
                                    listcolors[tempX][tempY] = "pink"
                                } else if (temptukerwarna2 == "green") {
                                    buttons[tempX][tempY].setBackgroundColor(
                                            ContextCompat.getColor(
                                                    applicationContext,
                                                    R.color.green
                                            )
                                    )
                                    listcolors[tempX][tempY] = "green"
                                } else if (temptukerwarna2 == "orange") {
                                    buttons[tempX][tempY].setBackgroundColor(
                                            ContextCompat.getColor(
                                                    applicationContext,
                                                    R.color.orange
                                            )
                                    )
                                    listcolors[tempX][tempY] = "orange"
                                } else if (temptukerwarna2 == "white") {
                                    buttons[tempX][tempY].setBackgroundColor(
                                            ContextCompat.getColor(
                                                    applicationContext,
                                                    R.color.white
                                            )
                                    )
                                    listcolors[tempX][tempY] = "white"
                                }
                                for (baris in 0..4) {
                                    for (kolom in 0..4) {
                                        print("${listcolors[kolom][baris]} - ")
                                    }
                                    println()
                                }

                                //
                                // listcolors[tempX][tempY]=temptukerwarna2
                                //                                listcolors[i][j]=temptukerwarna

                                var counterX = 0
                                var counterY = 0
                                var tempXkanan = tempX
                                var tempXkiri = tempX
                                var tempYatas = tempY
                                var tempYbawah = tempY
                                while (tempXkanan + 1 <= 4) {
                                    if (listcolors[tempXkanan + 1][tempY] ==
                                                    listcolors[tempX][tempY] && listcolors[tempX][tempY]!="white"
                                    ) {
                                        counterX++
                                        tempXkanan++
                                    } else {
                                        println("MASUK1")
                                        break
                                    }
                                }
                                while (tempXkiri - 1 >= 0) {
                                    if (listcolors[tempXkiri - 1][tempY] == listcolors[tempX][tempY]&& listcolors[tempX][tempY]!="white"
                                    ) {
                                        counterX++
                                        tempXkiri--
                                    } else {
                                        println("MASUK2")
                                        break
                                    }
                                }
                                while (tempYatas - 1 >= 0) {
                                    if (listcolors[tempX][tempYatas - 1] == listcolors[tempX][tempY]&& listcolors[tempX][tempY]!="white"
                                    ) {
                                        counterY++
                                        tempYatas--
                                    } else {
                                        println("MASUK3")
                                        break
                                    }
                                }
                                while (tempYbawah + 1 <= 4) {
                                    if (listcolors[tempX][tempYbawah + 1] ==
                                                    listcolors[tempX][tempY]&& listcolors[tempX][tempY]!="white"
                                    ) {
                                        counterY++
                                        tempYbawah++
                                    } else {
                                        println("MASUK4")
                                        break
                                    }
                                }
                                println("COUNTERX $counterX")
                                println("COUNTERY $counterY")
                                if (counterX >= 2) {
                                    for (k in tempXkiri..tempXkanan) {
                                        //                                        Thread.sleep(1000)
                                        buttons[k][tempY].setBackgroundColor(
                                                ContextCompat.getColor(
                                                        applicationContext,
                                                        R.color.white
                                                )
                                        )
                                        listcolors[k][tempY] = "white"
                                        score++
                                    }
                                    binding.labelScore.text = score.toString()
                                }
                                if (counterY >= 2) {
                                    for (k in tempYatas..tempYbawah) {
                                        //                                        Thread.sleep(1000)
                                        buttons[tempX][k].setBackgroundColor(
                                                ContextCompat.getColor(
                                                        applicationContext,
                                                        R.color.white
                                                )
                                        )
                                        listcolors[tempX][k] = "white"
                                        score++
                                    }
                                    binding.labelScore.text = score.toString()
                                }
                                counterX = 0
                                counterY = 0
                                var counterX2 = 0
                                var counterY2 = 0
                                var tempXkanan2 = i
                                var tempXkiri2 = i
                                var tempYatas2 = j
                                var tempYbawah2 = j
                                while (tempXkanan2 + 1 <= 4) {
                                    if (listcolors[tempXkanan2 + 1][j] == listcolors[i][j]&& listcolors[i][j]!="white") {
                                        counterX2++
                                        tempXkanan2++
                                    } else {
                                        println("MASUK5")
                                        break
                                    }
                                }
                                while (tempXkiri2 - 1 >= 0) {
                                    if (listcolors[tempXkiri2 - 1][j] == listcolors[i][j]&& listcolors[i][j]!="white") {
                                        counterX2++
                                        tempXkiri2--
                                    } else {
                                        println("MASUK6")
                                        break
                                    }
                                }
                                while (tempYatas2 - 1 >= 0) {
                                    if (listcolors[i][tempYatas2 - 1] == listcolors[i][j]&& listcolors[i][j]!="white") {
                                        counterY2++
                                        tempYatas2--
                                    } else {
                                        println("MASUK7")
                                        break
                                    }
                                }
                                while (tempYbawah2 + 1 <= 4) {
                                    if (listcolors[i][tempYbawah2 + 1] == listcolors[i][j]&& listcolors[i][j]!="white") {
                                        counterY2++
                                        tempYbawah2++
                                    } else {
                                        println("MASUK8")
                                        break
                                    }
                                }
                                if (counterX2 >= 2) {
                                    for (k in tempXkiri2..tempXkanan2) {
                                        //                                        Thread.sleep(1000)
                                        buttons[k][j].setBackgroundColor(
                                                ContextCompat.getColor(
                                                        applicationContext,
                                                        R.color.white
                                                )
                                        )
                                        listcolors[k][j] = "white"
                                        score++
                                    }
                                    binding.labelScore.text = score.toString()
                                }
                                if (counterY2 >= 2) {
                                    for (k in tempYatas2..tempYbawah2) {
                                        //                                        Thread.sleep(1000)
                                        buttons[i][k].setBackgroundColor(
                                                ContextCompat.getColor(
                                                        applicationContext,
                                                        R.color.white
                                                )
                                        )
                                        listcolors[i][k] = "white"
                                        score++
                                    }
                                    binding.labelScore.text = score.toString()
                                }

                                counterX = 0

                                println("COUNTERX2 $counterX2")
                                println("COUNTERY2 $counterY2")
                                counterX2 = 0
                                counterY2 = 0

//                                var counterX3 = 0
//                                var counterY3 = 0
//                                var tempXkanan3 = i
//                                var tempXkiri3 = i
//                                var tempYatas3 = j
//                                var tempYbawah3 = j
//
//                                while (tempXkanan3 + 1 <= 4) {
//                                    if (listcolors[tempXkanan3 + 1][j] ==
//                                                    listcolors[tempX][tempY]&& listcolors[tempX][tempY]!="white"
//                                    ) {
//                                        counterX3++
//                                        tempXkanan3++
//                                    } else {
//                                        println("MASUK9")
//                                        break
//                                    }
//                                }
//
//                                while (tempXkiri3 - 1 >= 0) {
//                                    if (listcolors[tempXkiri3 - 1][j] ==
//                                                    listcolors[tempX][tempY]&& listcolors[tempX][tempY]!="white"
//                                    ) {
//                                        counterX3++
//                                        tempXkiri3--
//                                    } else {
//                                        println("MASUK10")
//                                        break
//                                    }
//                                }
//
//                                while (tempYatas3 - 1 >= 0) {
//                                    if (listcolors[i][tempYatas3 - 1] == listcolors[tempX][tempY]&& listcolors[tempX][tempY]!="white") {
//                                        counterY3++
//                                        tempYatas3--
//                                    } else {
//                                        println("MASUK11")
//                                        break
//                                    }
//                                }
//
//                                while (tempYbawah3 + 1 <= 4) {
//                                    if (listcolors[i][tempYbawah3 + 1] == listcolors[tempX][tempY]&& listcolors[tempX][tempY]!="white"
//                                    ) {
//                                        counterY3++
//                                        tempYbawah3++
//                                    } else {
//                                        println("MASUK12")
//                                        break
//                                    }
//                                }
//
//                                if (counterX3 >= 2) {
//                                    for (k in tempXkiri3..tempXkanan3) {
//                                        //                                        Thread.sleep(1000)
//                                        buttons[k][j].setBackgroundColor(
//                                                ContextCompat.getColor(
//                                                        applicationContext,
//                                                        R.color.white
//                                                )
//                                        )
//                                        listcolors[k][j] = "white"
//                                        score++
//                                    }
//                                    binding.labelScore.text = score.toString()
//                                }
//
//                                if (counterY3 >= 2) {
//                                    for (k in tempYatas3..tempYbawah3) {
//                                        //                                        Thread.sleep(1000)
//                                        buttons[i][k].setBackgroundColor(
//                                                ContextCompat.getColor(
//                                                        applicationContext,
//                                                        R.color.white
//                                                )
//                                        )
//                                        listcolors[i][k] = "white"
//                                        score++
//                                    }
//                                    binding.labelScore.text = score.toString()
//                                }
//
//                                println("COUNTERX3 $counterX3")
//                                println("COUNTERY3 $counterY3")
//                                var counterX4 = 0
//                                var counterY4 = 0
//                                var tempXkanan4 = tempX
//                                var tempXkiri4 = tempX
//                                var tempYatas4 = tempY
//                                var tempYbawah4 = tempY
//
//                                while (tempXkanan4 + 1 < 5) {
//                                    if (listcolors[tempXkanan4 + 1][tempY] == listcolors[i][j]&& listcolors[tempX][tempY]!="white") {
//                                        counterX4++
//                                        tempXkanan4++
//                                    } else {
//                                        println("MASUK13")
//                                        break
//                                    }
//                                }
//
//                                while (tempXkiri4 - 1 >= 0) {
//                                    if (listcolors[tempXkiri4 - 1][tempY] == listcolors[i][j]&& listcolors[tempX][tempY]!="white") {
//                                        counterX4++
//                                        tempXkiri4--
//                                    } else {
//                                        println("MASUK14")
//                                        break
//                                    }
//                                }
//
//                                while (tempYatas4 - 1 >= 0) {
//                                    if (listcolors[tempX][tempYatas4 - 1] == listcolors[i][j]&& listcolors[tempX][tempY]!="white") {
//                                        counterY4++
//                                        tempYatas4--
//                                    } else {
//                                        println("MASUK15")
//                                        break
//                                    }
//                                }
//
//                                while (tempYbawah4 + 1 < 5) {
//                                    if (listcolors[tempX][tempYbawah4 + 1] == listcolors[i][j]&& listcolors[tempX][tempY]!="white") {
//                                        counterY4++
//                                        tempYbawah4++
//                                    } else {
//                                        println("MASUK16")
//                                        break
//                                    }
//                                }
//
//                                if (counterX4 >= 2) {
//                                    for (k in tempXkiri4..tempXkanan4) {
//                                        //                                        Thread.sleep(1000)
//                                        buttons[k][tempY].setBackgroundColor(
//                                                ContextCompat.getColor(
//                                                        applicationContext,
//                                                        R.color.white
//                                                )
//                                        )
//                                        listcolors[k][tempY] = "white"
//                                        score++
//                                    }
//                                    binding.labelScore.text = score.toString()
//                                }
//
//                                if (counterY4 >= 2) {
//                                    for (k in tempYatas4..tempYbawah4) {
//                                        //                                        Thread.sleep(1000)
//                                        buttons[tempX][k].setBackgroundColor(
//                                                ContextCompat.getColor(
//                                                        applicationContext,
//                                                        R.color.white
//                                                )
//                                        )
//                                        listcolors[tempX][k] = "white"
//                                        score++
//                                    }
//                                    binding.labelScore.text = score.toString()
//                                }
//                                println("COUNTERX4 $counterX4")
//                                println("COUNTERY4 $counterY4")

                            }
                        }
                    }
                }
            }
        }
        binding.buttonEnd.setOnClickListener(){
            selese=true
            binding.buttonRestart.text="Next"
        }
        binding.labelNama.setOnClickListener() {
            if(counterdblclick==1){
                counterdblclick=2;
            }
            else{
                var ex = (0..4).random()
                var ye = (0..4).random()
                while(listcolors[ex][ye]=="purple"){
                    ex = (0..4).random()
                    ye = (0..4).random()
                }
                buttons[ex][ye].setBackgroundColor(
                        ContextCompat.getColor(applicationContext, R.color.purple)
                )
                listcolors[ex][ye] = "purple"
                counterdblclick=1
            }
        }
        binding.buttonQuit.setOnClickListener() { finish() }
        binding.buttonRestart.setOnClickListener {
            if(selese==false){

                restartGame(listcolors)
                score = 0
                binding.labelScore.text = score.toString()
            }
            else{
                val intent = Intent(this, Finish::class.java)
                intent.putExtra("nama", intent.getStringExtra("nama"))
                intent.putExtra("score", score)
                startActivity(intent)
            }
        }
    }
    fun restartGame(listcolors: Array<Array<String>>) {

        buttons =
                arrayOf(
                        arrayOf(binding.b00, binding.b01, binding.b02, binding.b03, binding.b04),
                        arrayOf(binding.b10, binding.b11, binding.b12, binding.b13, binding.b14),
                        arrayOf(binding.b20, binding.b21, binding.b22, binding.b23, binding.b24),
                        arrayOf(binding.b30, binding.b31, binding.b32, binding.b33, binding.b34),
                        arrayOf(binding.b40, binding.b41, binding.b42, binding.b43, binding.b44)
                )

        var tempwarna =
                arrayOf(
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1,
                        -1
                )
        for (i in 0..3) {
            var ctr = 0
            while (ctr < 6) {
                var random = (0..24).random()
                if (tempwarna[random] == -1) {
                    tempwarna[random] = i
                    ctr++
                }
            }
        }
        for (i in 0..24) {
            if (tempwarna[i] == -1) {
                var random = (0..3).random()
                tempwarna[i] = random
            }
        }
        for (i in 0..4) {
            for (j in 0..4) {
                if (tempwarna[i * 5 + j] == 0) {
                    buttons[i][j].setBackgroundColor(
                            ContextCompat.getColor(applicationContext, R.color.blue)
                    )
                    listcolors[i][j] = "blue"
                } else if (tempwarna[i * 5 + j] == 1) {
                    buttons[i][j].setBackgroundColor(
                            ContextCompat.getColor(applicationContext, R.color.pink)
                    )
                    listcolors[i][j] = "pink"
                } else if (tempwarna[i * 5 + j] == 2) {
                    buttons[i][j].setBackgroundColor(
                            ContextCompat.getColor(applicationContext, R.color.green)
                    )
                    listcolors[i][j] = "green"
                } else if (tempwarna[i * 5 + j] == 3) {
                    buttons[i][j].setBackgroundColor(
                            ContextCompat.getColor(applicationContext, R.color.orange)
                    )
                    listcolors[i][j] = "orange"
                }
            }
        }
    }
}
