package com.example.m5baru

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintSet.Constraint
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView


class BookAdapter(
    val data: MutableList<Book>,
    val layout: Int,
    var onDetailClickListener: ((Book)-> Unit),
    var onFavourite: (() -> Unit)? = null
) : RecyclerView.Adapter<BookAdapter.ViewHolder>() {
    class ViewHolder(val row: View) : RecyclerView.ViewHolder(row) {
        val nrpTv: TextView = row.findViewById(R.id.textView)
        val like: ImageView = row.findViewById(R.id.imageView)
        val unlike: ImageView = row.findViewById(R.id.imageView2)
        val author: TextView = row.findViewById(R.id.textView3)
        //        val namaTv:TextView = row.findViewById(R.id.tvNama)
        //        val jurusanTv:TextView = row.findViewById(R.id.tvJurusan)
        val btnDeleteList: ImageView = row.findViewById(R.id.imageView3)
        val semua: View =row.findViewById(R.id.c1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var itemView = LayoutInflater.from(parent.context)
        return ViewHolder(itemView.inflate(layout, parent, false))
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val book = data[position]
        holder.nrpTv.text = book.title
        holder.author.text = book.author
        if (book.status == true) {
            holder.like.visibility = View.VISIBLE
            holder.unlike.visibility = View.INVISIBLE
        } else {
            holder.like.visibility = View.INVISIBLE
            holder.unlike.visibility = View.VISIBLE
        }
        holder.like.setOnClickListener() {
            data[holder.adapterPosition].status = false
            onFavourite?.invoke()
            notifyDataSetChanged()
        }
        holder.unlike.setOnClickListener() {
            data[holder.adapterPosition].status = true
            onFavourite?.invoke()
            notifyDataSetChanged()
        }
        holder.btnDeleteList.setOnClickListener {
            for (i in 0 until Data.books.size) {
                if (Data.books[i].title == data[holder.adapterPosition].title) {
                    Data.books[i].owned = false
                    break
                }
            }
            var idx=-1
            for (i in 0 until Data.lib.size){
                if(Data.lib[i].title==book.title){
                    idx=i
                    break
                }
            }
            if(idx!=-1){
                Data.lib.removeAt(idx)
            }
            data.removeAt(holder.adapterPosition)
            notifyItemRemoved(
                holder.adapterPosition
            )
        }
        holder.semua.setOnClickListener(){
            onDetailClickListener.invoke(book)
        }
        //        holder.btnEditList.setOnClickListener{
        //            onEditClickListener.invoke(mhs)
        //        }
    }
}