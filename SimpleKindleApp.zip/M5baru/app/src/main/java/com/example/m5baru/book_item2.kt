package com.example.m5baru

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class book_item2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book_item2)
    }
}