package com.example.m5baru

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintSet.Constraint
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView


class HistoryAdapter(
    val data: MutableList<Book>,
    val layout: Int
) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {
    class ViewHolder(val row: View) : RecyclerView.ViewHolder(row) {
        val judul: TextView = row.findViewById(R.id.textView7)
        val author: TextView = row.findViewById(R.id.textView26)
        val harga: TextView = row.findViewById(R.id.textView25)
        val tanggal: TextView = row.findViewById(R.id.textView30)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var itemView = LayoutInflater.from(parent.context)
        return ViewHolder(itemView.inflate(layout, parent, false))
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val book = data[position]
        holder.judul.text = book.title
        holder.author.text = book.author
        holder.tanggal.text = book.tanggal
        holder.harga.text = book.price.toString()
    }
}