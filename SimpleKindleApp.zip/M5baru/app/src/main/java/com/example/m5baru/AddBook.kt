package com.example.m5baru

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.navigation.fragment.findNavController



class AddBook : Fragment() {

    lateinit var button3:Button
    lateinit var editTextText2: EditText
    lateinit var editTextText4: EditText
    lateinit var editTextTextMultiLine: EditText

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_book, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        button3=view.findViewById(R.id.button3)
        editTextText2=view.findViewById(R.id.editTextText2)
        editTextText4=view.findViewById(R.id.editTextText4)
        editTextTextMultiLine=view.findViewById(R.id.editTextTextMultiLine)
        button3.setOnClickListener(){
            if(editTextText2.text.toString()==""||editTextText4.text.toString()==""||editTextTextMultiLine.text.toString()==""){
                Toast.makeText(this.context, "ADA INPUT KOSONG", Toast.LENGTH_SHORT).show()
            }
            else{
                Data.lib.add(Book(editTextText2.text.toString(),editTextText4.text.toString(),editTextTextMultiLine.text.toString(),0,false,true))
                Toast.makeText(this.context, "Berhasil menambahkan buku", Toast.LENGTH_SHORT).show()
                findNavController().navigate(R.id.action_global_home2)
            }
        }
    }
}