package com.example.m5baru

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.navigation.fragment.findNavController


class Login : Fragment() {

    lateinit var editTextText3:EditText
    lateinit var editTextText5:EditText
    lateinit var button4: Button
    lateinit var button8: Button
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_login, container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        editTextText3=view.findViewById(R.id.editTextText3)
        editTextText5=view.findViewById(R.id.editTextText5)
        button4=view.findViewById(R.id.button4)
        button8=view.findViewById(R.id.button8)
        button4.setOnClickListener(){
            var found=false;
            for (i in 0 until Data.users.size){
                if(Data.users[i].username==editTextText3.text.toString()&&Data.users[i].password==editTextText5.text.toString()){
                    Data.aktif=Data.users[i]
                    found=true
                }
            }
            if(found){
                findNavController().navigate(R.id.action_global_home2)
            }
            else{
                Toast.makeText(this.context, "Username/password salah", Toast.LENGTH_SHORT).show()
            }
        }
        button8.setOnClickListener(){
            findNavController().navigate(R.id.action_global_register)
        }
    }


}