package com.example.m5baru
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

//Parcelize digunakan untuk mengirimkan object dalam arguments
@Parcelize
class Book(var title: String, var author: String, var synopsis: String, var price: Int, var status:Boolean, var owned:Boolean):Parcelable {
    var tanggal=""
    init {
        tanggal=""
    }
    constructor (title: String, author: String,  synopsis: String,  price: Int,  status:Boolean,  owned:Boolean, tanggalx:String) : this(title, author, synopsis, price, status, owned) {
        tanggal=tanggalx
    }
}