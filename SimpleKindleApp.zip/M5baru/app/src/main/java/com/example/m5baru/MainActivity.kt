package com.example.m5baru

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentContainerView
import androidx.navigation.fragment.findNavController

class MainActivity : AppCompatActivity() {
    lateinit var container: FragmentContainerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        container = findViewById(R.id.fragment_container)
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        //menu ini digunakan untuk memilih menu mana yang akan dilekatkan pada activity
        menuInflater.inflate(R.menu.nav_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        //method ini untuk melakukan handling apabila ada item menu yang dipilih
        when(item.itemId){
            R.id.menu_library->{
                //ini untuk aksi mengganti fragment tanpa mengirimkan arguments
                container.getFragment<Fragment>().findNavController().navigate(R.id.action_global_home2)
            }
            R.id.menu_explore->{
                container.getFragment<Fragment>().findNavController().navigate(R.id.action_global_browse)
            }
            else->{
                container.getFragment<Fragment>().findNavController().navigate(R.id.action_global_profile)
            }
        }
        return super.onOptionsItemSelected(item)
    }
}