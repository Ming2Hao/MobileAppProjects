package com.example.m5baru

object Data {
    val books = arrayListOf<Book>(
        Book(
            "Pride and Prejudice",
            "Jane Austen",
            "In Jane Austen's timeless masterpiece, the lives of the Bennet family are turned upside down when the wealthy and eligible bachelor Mr. Bingley moves into the neighborhood. The story follows the spirited Elizabeth Bennet as she navigates the complexities of societal expectations, love, and family dynamics, particularly with the enigmatic Mr. Darcy.",
            150000,
            true,
            true
        ),
        Book(
            "Emma",
            "Jane Austen",
            "Set in the charming English countryside, Jane Austen's Emma follows the misadventures of the well-meaning but misguided Emma Woodhouse, who fancies herself a matchmaker. As Emma meddles in the romantic affairs of her friends and neighbors, she discovers that love is a far more intricate and unpredictable force than she ever imagined.",
            120000,
            false,
            true
        ),
        Book(
            "The Last Battle",
            "C.S. Lewis",
            "C.S. Lewis's epic conclusion to The Chronicles of Narnia series sees the land of Narnia facing its darkest hour as it is besieged by the forces of darkness. As old friends reunite and new alliances are forged, the fate of Narnia hangs in the balance. With themes of courage, sacrifice, and redemption, The Last Battle is a timeless tale of ultimate victory over evil.",
            110000,
            true,
            false
        ),
        Book(
            "Crooked House",
            "Agatha Christie",
            "Multi-millionaire Aristide Leonides has just died, apparently of a heart attack. Private investigator Charles Hayward is approached by his granddaughter Sophia and asked to investigate his death as she believes he was murdered. Hayward takes on the case and visits the Leonides estate, questioning the family. He discovers that it is far from a simple case - the family is incredibly dysfunctional and nothing is as it seems.",
            135000,
            false,
            true
        ),
        Book(
            "Great Expectations",
            "Charles Dickens",
            "In Charles Dickens's Great Expectations, the young orphan Pip encounters unexpected opportunities and challenges as he navigates the intricacies of Victorian society. From his mysterious benefactor to his tumultuous relationships with the enigmatic Estella and the convict Magwitch, Pip's journey is a gripping exploration of ambition, love, and the pursuit of identity.",
            155000,
            false,
            false
        ),
        Book(
            "A Caribbean Mystery",
            "Agatha Christie",
            "Agatha Christie's A Caribbean Mystery finds the indomitable Miss Marple embroiled in a murder mystery while vacationing on a tranquil Caribbean island. As she delves into the secrets and scandals of the island's elite, Miss Marple uncovers a web of deceit and betrayal, proving that even paradise can harbor deadly secrets.",
            10000,
            false,
            false
        ),
        Book(
            "A Christmas Carol",
            "Charles Dickens",
            "Charles Dickens's timeless tale A Christmas Carol follows the miserly Ebenezer Scrooge as he is visited by the ghosts of Christmas Past, Present, and Yet to Come. Through these spectral encounters, Scrooge learns the true meaning of Christmas and the importance of compassion, generosity, and redemption.",
            115000,
            false,
            false
        ),
        Book(
            "And Then There Were None",
            "Agatha Christie",
            "In Agatha Christie's masterful mystery, ten strangers are lured to a remote island under false pretenses, only to find themselves accused of past crimes. As they are picked off one by one, the remaining guests must confront their own guilt and unravel the identity of their unseen assailant before it's too late.",
            145000,
            false,
            true
        ),
        Book(
            "Anna Karenina",
            "Leo Tolstoy",
            "Leo Tolstoy's epic novel Anna Karenina explores the intersecting lives of a diverse cast of characters against the backdrop of 19th-century Russian society. From the tragic love affair between the titular Anna and the dashing Count Vronsky to the moral struggles of the idealistic Levin, Tolstoy's sweeping narrative delves into themes of love, betrayal, and the search for meaning in a rapidly changing world.",
            165000,
            false,
            false
        ),
        Book(
            "Little Women",
            "Louisa May Alcott",
            "Louisa May Alcott's beloved classic Little Women follows the lives of the March sisters—Meg, Jo, Beth, and Amy—as they navigate the challenges of adolescence and womanhood during the Civil War era. Through their joys and sorrows, triumphs and setbacks, the sisters learn the enduring power of family, friendship, and the pursuit of their dreams.",
            125000,
            false,
            false
        ),
        Book(
            "Persuasion",
            "Jane Austen",
            "In Jane Austen's final completed novel, Persuasion, Anne Elliot is persuaded to break off her engagement to the dashing but penniless Captain Wentworth. Eight years later, they are unexpectedly reunited, and Anne must confront her lingering feelings for Wentworth as well as the societal pressures that once drove them apart. With its themes of second chances and the enduring power of love, Persuasion is a poignant exploration of heartache, regret, and redemption.",
            120000,
            true,
            true
        ),
        Book(
            "War and Peace",
            "Leo Tolstoy",
            "Leo Tolstoy's monumental epic War and Peace traces the intertwining lives of Russian aristocrats against the backdrop of the Napoleonic Wars. From the glittering salons of St. Petersburg to the blood-soaked battlefields of Austerlitz and Borodino, Tolstoy's panoramic narrative explores the grand sweep of history and the timeless struggles of love, honor, and destiny.",
            175000,
            false,
            false
        ),
        Book(
            "A Tale of Two Cities",
            "Charles Dickens",
            "Charles Dickens's historical novel A Tale of Two Cities vividly depicts the turmoil of the French Revolution and its impact on both sides of the English Channel. Against the backdrop of revolution and rebellion, the lives of the noble Charles Darnay, the dissolute Sydney Carton, and the steadfast Lucie Manette become inexorably intertwined in a tale of sacrifice, redemption, and the enduring power of love.",
            160000,
            false,
            false
        )
    )
    val lib= arrayListOf<Book>(
        Book(
            "Pride and Prejudice",
            "Jane Austen",
            "In Jane Austen's timeless masterpiece, the lives of the Bennet family are turned upside down when the wealthy and eligible bachelor Mr. Bingley moves into the neighborhood. The story follows the spirited Elizabeth Bennet as she navigates the complexities of societal expectations, love, and family dynamics, particularly with the enigmatic Mr. Darcy.",
            150000,
            true,
            true
        ),
        Book(
            "Emma",
            "Jane Austen",
            "Set in the charming English countryside, Jane Austen's Emma follows the misadventures of the well-meaning but misguided Emma Woodhouse, who fancies herself a matchmaker. As Emma meddles in the romantic affairs of her friends and neighbors, she discovers that love is a far more intricate and unpredictable force than she ever imagined.",
            120000,
            false,
            true
        ),
        Book(
            "And Then There Were None",
            "Agatha Christie",
            "In Agatha Christie's masterful mystery, ten strangers are lured to a remote island under false pretenses, only to find themselves accused of past crimes. As they are picked off one by one, the remaining guests must confront their own guilt and unravel the identity of their unseen assailant before it's too late.",
            145000,
            false,
            true
        ),
        Book(
            "Persuasion",
            "Jane Austen",
            "In Jane Austen's final completed novel, Persuasion, Anne Elliot is persuaded to break off her engagement to the dashing but penniless Captain Wentworth. Eight years later, they are unexpectedly reunited, and Anne must confront her lingering feelings for Wentworth as well as the societal pressures that once drove them apart. With its themes of second chances and the enduring power of love, Persuasion is a poignant exploration of heartache, regret, and redemption.",
            120000,
            true,
            true
        ),
    )
    var users= arrayListOf<User>(User("adi","adi1",100000,lib),User("hehe","hehe1",900000,lib))
    var aktif=User("","",0,lib)
    var saldo=500000
}
