package com.example.m5baru

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import java.text.SimpleDateFormat
import java.util.Date

class Detail : Fragment() {

    lateinit var textView5: TextView
    lateinit var textView10: TextView
    lateinit var textView13: TextView
    lateinit var textView14: TextView
    lateinit var textView15: TextView
    lateinit var button5: Button
    lateinit var button6: Button
    lateinit var buku : Book
    lateinit var from: String

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail, container, false)
    }

    val navArgs:DetailArgs by navArgs<DetailArgs>()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        textView5 = view.findViewById(R.id.textView5)
        textView10 = view.findViewById(R.id.textView10)
        textView13 = view.findViewById(R.id.textView13)
        textView14 = view.findViewById(R.id.textView14)
        textView15 = view.findViewById(R.id.textView15)
        button5 = view.findViewById(R.id.button5)
        button6 = view.findViewById(R.id.button6)
        textView5.text=Data.aktif.saldo.toString()
        lateinit var temp: Book
        buku= navArgs.book
        from = navArgs.from
        if(from=="lib"){
            for (i in 0 until Data.lib.size){
                if(Data.lib[i].title==buku.title){
                    temp=Data.lib[i]
                }
            }
        }
        else{
            for (i in 0 until Data.books.size){
                if(Data.books[i].title==buku.title){
                    temp=Data.books[i]
                }
            }
        }
        textView10.text=buku.title
        textView13.text=temp.author
        textView14.text=temp.synopsis
        button5.text="Buy IDR "+temp.price.toString()
        if(temp.owned==true){
            textView15.text=""
            button5.visibility= View.INVISIBLE
        }
        else{
            textView15.text="IDR "+temp.price.toString()
        }
        button6.setOnClickListener(){
            findNavController().popBackStack()
        }
        button5.setOnClickListener(){
            if(Data.aktif.saldo>=temp.price){
                Data.aktif.saldo-=temp.price
                temp.owned=true
                Data.lib.add(Book(temp.title,temp.author,temp.synopsis,temp.price,false,true))
                val sdf = SimpleDateFormat("dd/MM/yyyy")
                val currentDate = sdf.format(Date())
                Data.aktif.history.add(Book(temp.title,temp.author,temp.synopsis,temp.price,false,true,currentDate))
                refresh(temp)
            }
            else{
                Toast.makeText(this.context, "Saldo Anda Tidak Cukup", Toast.LENGTH_SHORT).show()
            }
        }
    }
    fun refresh(temp:Book){
        textView5.text=Data.aktif.saldo.toString()
        textView10.text=buku.title
        textView13.text=temp.author
        textView14.text=temp.synopsis
        button5.text="Buy IDR "+temp.price.toString()
        if(temp.owned==true){
            textView15.text=""
            button5.visibility= View.INVISIBLE
        }
        else{
            textView15.text="IDR "+temp.price.toString()
        }
    }
}