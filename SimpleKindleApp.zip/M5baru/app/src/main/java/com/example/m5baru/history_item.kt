package com.example.m5baru

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class history_item : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history_item)
    }
}