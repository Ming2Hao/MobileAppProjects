package com.example.m5baru

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class BookAdapter2(val data: MutableList<Book>,
                   val layout: Int,
                   var onDetailClickListener: ((Book)-> Unit)
) : RecyclerView.Adapter<BookAdapter2.ViewHolder>() {
    class ViewHolder(val row: View) : RecyclerView.ViewHolder(row) {
        val nrpTv: TextView = row.findViewById(R.id.textView16)
        val author: TextView = row.findViewById(R.id.textView17)
        val btnBuy: Button = row.findViewById(R.id.button7)
        val semua: View =row.findViewById(R.id.c1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var itemView = LayoutInflater.from(parent.context)
        return ViewHolder(itemView.inflate(layout, parent, false))
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val book = data[position]
        holder.nrpTv.text = book.title
        holder.author.text = book.author
        if (book.owned == true) {
            holder.btnBuy.visibility=View.INVISIBLE
        }
        holder.semua.setOnClickListener(){
            onDetailClickListener.invoke(book)
        }
        holder.btnBuy.setOnClickListener(){
            onDetailClickListener.invoke(book)
        }
        //        holder.btnEditList.setOnClickListener{
        //            onEditClickListener.invoke(mhs)
        //        }
    }
}