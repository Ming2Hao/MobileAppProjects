package com.example.m5baru

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.navigation.fragment.findNavController


class Profile : Fragment() {

    lateinit var username2:TextView
    lateinit var duit:TextView
    lateinit var m1:LinearLayout
    lateinit var m2:LinearLayout
    lateinit var m3:LinearLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        username2=view.findViewById(R.id.username2)
        duit=view.findViewById(R.id.duit)
        m1=view.findViewById(R.id.m1)
        m2=view.findViewById(R.id.m2)
        m3=view.findViewById(R.id.m3)
        username2.text=Data.aktif.username
        duit.text=Data.aktif.saldo.toString()
        m1.setOnClickListener(){

        }
        m2.setOnClickListener(){
            findNavController().navigate(R.id.action_global_history)
        }
        m3.setOnClickListener(){
            findNavController().navigate(R.id.action_global_login)
        }
    }
}