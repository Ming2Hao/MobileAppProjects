package com.example.m5baru

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.core.widget.doOnTextChanged
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class home : Fragment() {
    //    private lateinit var binding: FragmentHomeBinding
    lateinit var rvBook: RecyclerView
    lateinit var BookAdapter: BookAdapter
    lateinit var textView5: TextView
    lateinit var button2: Button
    lateinit var editTextText: EditText
    lateinit var imageView5: ImageView
    lateinit var button: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        binding = FragmentHomeBinding.inflate(layoutInflater)
        rvBook=view.findViewById(R.id.rvBook)
        textView5=view.findViewById(R.id.textView5)
        button2=view.findViewById(R.id.button2)
        editTextText=view.findViewById(R.id.editTextText)
        imageView5=view.findViewById(R.id.imageView5)
        button=view.findViewById(R.id.button)
        textView5.text=Data.aktif.saldo.toString()
        lateinit var layoutManager: RecyclerView.LayoutManager
        var layout:Int = R.layout.activity_book_item
        layoutManager = LinearLayoutManager(this.context)
        layoutManager = LinearLayoutManager(this.context)
        BookAdapter = BookAdapter(Data.lib.toMutableList(), R.layout.activity_book_item,{book -> detil(book) })
        rvBook.apply {
            this.layoutManager = layoutManager
            this.adapter = BookAdapter
        }
        BookAdapter.notifyDataSetChanged()
        button2.setOnClickListener(){
            findNavController().navigate(R.id.action_global_addBook)
        }
        editTextText.doOnTextChanged { text, start, before, count -> refresh2(text.toString().lowercase()) }
        imageView5.setOnClickListener(){
            Data.aktif.saldo+=100000
            textView5.text=Data.aktif.saldo.toString()
        }
        button.setOnClickListener(){
            findNavController().navigate(R.id.action_global_browse)
//            val intent = Intent(this, Browse::class.java)
//            startActivity(intent)
        }

    }
    override fun onResume() {
        super.onResume()
        editTextText.setText("")
        textView5.text=Data.aktif.saldo.toString()
        refresh()
    }
    fun refresh(){
        BookAdapter = BookAdapter(Data.lib.toMutableList(), R.layout.activity_book_item,{book -> detil(book) })
        rvBook.apply {
            this.layoutManager = layoutManager
            this.adapter = BookAdapter
        }
        BookAdapter.notifyDataSetChanged()
    }
    fun refresh2(x: String){
        BookAdapter = BookAdapter(Data.lib.toMutableList().filter { it.title.lowercase().contains(x) }.toMutableList(), R.layout.activity_book_item,{book -> detil(book) })
        rvBook.apply {
            this.layoutManager = layoutManager
            this.adapter = BookAdapter
        }
        BookAdapter.notifyDataSetChanged()
    }
    fun detil(buku: Book){
        val action = DetailDirections.actionGlobalDetail(buku,"lib")
        findNavController().navigate(action)
//        findNavController().navigate(action)
//        val intent = Intent(this, Detail::class.java)
//        var index=-1
//        var title=buku.title
//        intent.putExtra("from","lib")
//        intent.putExtra("judul",title)
//        startActivity(intent)
    }

}

