package com.example.m5baru

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.navigation.fragment.findNavController


class Register : Fragment() {

    lateinit var username:EditText
    lateinit var password:EditText
    lateinit var confirm:EditText
    lateinit var regis:Button
    lateinit var log:Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_register, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        username=view.findViewById(R.id.username)
        password=view.findViewById(R.id.password)
        confirm=view.findViewById(R.id.confirm)
        regis=view.findViewById(R.id.regis)
        log=view.findViewById(R.id.log)
        regis.setOnClickListener(){
            if(username.text.toString()=="admin"){
                Toast.makeText(this.context, "Username Tidak Boleh Admin", Toast.LENGTH_SHORT).show()
            }
            else if(password.text.toString()!=confirm.text.toString()){
                Toast.makeText(this.context, "Password dan confirm password tidak sama", Toast.LENGTH_SHORT).show()
            }
            else if(password.text.toString()==""||username.text.toString()==""){
                Toast.makeText(this.context, "Field ada yang kosong", Toast.LENGTH_SHORT).show()
            }
            else{
                var found=false
                for (i in 0 until Data.users.size){
                    if(Data.users[i].username==username.text.toString()){
                        found=true
                    }
                }
                if(found==true){
                    Toast.makeText(this.context, "username sudah ada", Toast.LENGTH_SHORT).show()
                }
                else{
                    Data.users.add(User(username.text.toString(),password.text.toString(),0,arrayListOf<Book>()))
                }
            }
        }
        log.setOnClickListener(){
            findNavController().navigate(R.id.action_global_login)
        }
    }

}