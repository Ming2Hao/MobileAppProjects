package com.example.m5baru
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

//Parcelize digunakan untuk mengirimkan object dalam arguments
@Parcelize
class User(var username: String, var password: String, var saldo: Int, var history: MutableList<Book>):Parcelable {}