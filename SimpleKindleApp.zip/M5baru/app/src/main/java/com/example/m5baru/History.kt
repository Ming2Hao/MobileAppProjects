package com.example.m5baru

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class History : Fragment() {


    lateinit var button9:Button
    lateinit var rvBook:RecyclerView
    lateinit var historyAdapter: HistoryAdapter
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        button9=view.findViewById(R.id.button9)
        rvBook=view.findViewById(R.id.rvBook)
        lateinit var layoutManager: RecyclerView.LayoutManager
        layoutManager = LinearLayoutManager(this.context)

        historyAdapter = HistoryAdapter(Data.aktif.history, R.layout.activity_history_item)
        rvBook.apply {
            this.layoutManager = layoutManager
            this.adapter = historyAdapter
        }
        historyAdapter.notifyDataSetChanged()


        button9.setOnClickListener(){
            findNavController().navigate(R.id.action_global_profile)
        }
    }

}